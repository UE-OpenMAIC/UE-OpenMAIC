PAMAP2 full_sensor + keep activity_id=0 support for ClaSP

Install:
  1) Backup your current file:
     D:\code\teacherT2S\baseline\clasp\_shard\clasp_preprocessing.py

  2) Copy the patched file:
     clasp_preprocessing.py
     to:
     D:\code\teacherT2S\baseline\clasp\_shard\clasp_preprocessing.py

  3) Put these two files in:
     D:\code\teacherT2S\baseline\clasp\pamap2\
       RUN_CLASP_PAMAP2_KEEP0.cmd
       pamap2_keep0_clasp_config.txt

Run:
  double-click:
    D:\code\teacherT2S\baseline\clasp\pamap2\RUN_CLASP_PAMAP2_KEEP0.cmd

What it runs:
  datasets = pamap2
  loader   = PAMAP2_keep0
  feature  = full_sensor, raw[:, 2:]
  zero     = keep activity_id=0
  true K   = num_states=0, i.e. oracle K for TimeSeriesKMeans

Expected case display:
  PAMAP2_keep0/subject101
  PAMAP2_keep0/subject102
  ...
