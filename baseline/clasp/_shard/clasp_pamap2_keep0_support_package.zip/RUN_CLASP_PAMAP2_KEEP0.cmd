@echo off
chcp 65001 >nul
setlocal EnableExtensions EnableDelayedExpansion

REM ============================================================
REM ClaSP-TKMeans PAMAP2 full_sensor keep0 baseline - DIRECT PRINT
REM
REM Expected folder:
REM   D:\code\teacherT2S\baseline\clasp\pamap2\
REM
REM Required sibling folder:
REM   D:\code\teacherT2S\baseline\clasp\_shard\
REM ============================================================

set "SCRIPT_DIR=%~dp0"
set "CLASP_ROOT=%SCRIPT_DIR%.."
set "SHARD_DIR=%CLASP_ROOT%\_shard"
set "CONFIG=%SCRIPT_DIR%pamap2_keep0_clasp_config.txt"
set "CONDA_ENV=clasp_ts"

echo ============================================================
echo ClaSP-TKMeans PAMAP2 full_sensor keep0 baseline - DIRECT PRINT
echo No Python output redirection. Output prints directly in this CMD.
echo ============================================================
echo.
echo [INFO] Script folder:
echo   %SCRIPT_DIR%
echo [INFO] ClaSP baseline root:
echo   %CLASP_ROOT%
echo [INFO] Shard folder:
echo   %SHARD_DIR%
echo [INFO] Config:
echo   %CONFIG%
echo [INFO] Conda env:
echo   %CONDA_ENV%
echo.

REM ------------------------------------------------------------
REM Find conda.bat
REM ------------------------------------------------------------
set "CONDA_BAT="

where conda >nul 2>nul
if not errorlevel 1 (
    for /f "delims=" %%C in ('where conda 2^>nul') do (
        if not defined CONDA_BAT set "CONDA_BAT=%%C"
    )
)

if not defined CONDA_BAT (
    if exist "D:\software\anaconda\condabin\conda.bat" set "CONDA_BAT=D:\software\anaconda\condabin\conda.bat"
)

if not defined CONDA_BAT (
    if exist "D:\Anaconda\condabin\conda.bat" set "CONDA_BAT=D:\Anaconda\condabin\conda.bat"
)

if not defined CONDA_BAT (
    echo [ERROR] Cannot find conda.
    echo Please open Anaconda Prompt, cd to this folder, and run this CMD again.
    echo.
    cmd /k
    exit /b 1
)

if not exist "%CONFIG%" (
    echo [ERROR] Missing config:
    echo   %CONFIG%
    echo.
    cmd /k
    exit /b 1
)

if not exist "%SHARD_DIR%\launcher.py" (
    echo [ERROR] Missing launcher:
    echo   %SHARD_DIR%\launcher.py
    echo.
    cmd /k
    exit /b 1
)

echo [RUN] Activating conda environment...
call "%CONDA_BAT%" activate "%CONDA_ENV%"
if errorlevel 1 (
    echo [ERROR] Failed to activate conda env: %CONDA_ENV%
    echo.
    call "%CONDA_BAT%" env list
    echo.
    cmd /k
    exit /b 1
)

set "PYTHONNOUSERSITE=1"

echo [CHECK] Python in current env:
where python
echo.

echo [CHECK] Selected Python:
python -c "import sys; print(sys.executable)"
echo.

echo [CHECK] Import sanity check:
python -c "import sys, numpy, pandas, sklearn, scipy; print('exe=', sys.executable); print('numpy=', numpy.__version__); print('pandas=', pandas.__version__); print('sklearn=', sklearn.__version__); print('scipy=', scipy.__version__)"
if errorlevel 1 (
    echo [ERROR] Import sanity check failed.
    echo.
    cmd /k
    exit /b 1
)

echo.
echo ============================================================
echo Running command:
echo python -u "%SHARD_DIR%\launcher.py" --config "%CONFIG%"
echo ============================================================
echo.

python -u "%SHARD_DIR%\launcher.py" --config "%CONFIG%"

set "ERR=%ERRORLEVEL%"

if not "%ERR%"=="0" (
    echo.
    echo ============================================================
    echo FAILED.
    echo Exit code: %ERR%
    echo ============================================================
    echo.
    echo Window is intentionally kept open.
    echo Type exit and press Enter to close it.
    echo ============================================================
    cmd /k
    exit /b %ERR%
)

echo.
echo ============================================================
echo DONE.
echo Outputs:
echo   %SCRIPT_DIR%results_clasp_pamap2_fullsensor_keep0
echo ============================================================
echo.
echo Window is intentionally kept open.
echo Type exit and press Enter to close it.
echo ============================================================
cmd /k
exit /b 0
